class CustomError extends Error{

    constructor (args) {
        super(args)
        this.message = "Custom Error"
    }
    throwGenericError() {
        throw new Error("Generic Error")
    }

    thorwCustomError() {
        throw new CustomError().message
    }
}

const myError = new CustomError();
console.log("Force Generic error")

try {
    console.log("Generic error try block")
    myError.throwGenericError();
} catch {
    console.log("Generic error catch block")
    console.log(myError.throwGenericError());
} finally {
    console.log("Generic error finally block")
}

console.log("Force custom error")
try {
    console.log("custom error try block")
    myError.thorwCustomError();
} catch {
    console.log("custom custom catch block")
    console.log(myError.thorwCustomError());
} finally {
    console.log("custom error finally block")
}